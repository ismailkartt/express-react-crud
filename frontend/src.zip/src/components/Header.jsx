import React from "react";
import "./header.css";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <div className="header">
      <a href="/" className="logo">
        User Management System
      </a>
      <div>
        <a href="/" className="active">
          Home
        </a>
        <a href="/" className="active">
          Add New User
        </a>
      </div>
    </div>
  );
};

export default Header;
